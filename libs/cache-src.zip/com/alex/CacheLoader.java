package com.alex;

public final class CacheLoader {

    private CacheLoader() {
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Usage: java -jar cache.jar <cache_path>");
            System.exit(1);
        }

        try {
            Cache.init(args[0]);
            System.out.println("Cache initialized: " + args[0]);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(2);
        }
    }
}
