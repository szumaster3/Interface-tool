package com.alex.utils;

import com.alex.io.OutputStream;

import java.math.BigInteger;
import java.util.Locale;

public final class Utils {

    private Utils() {
    }

    public static byte[] cryptRSA(byte[] data, BigInteger exponent, BigInteger modulus) {
        return new BigInteger(data).modPow(exponent, modulus).toByteArray();
    }

    public static byte[] getArchivePacketData(int indexId, int archiveId, byte[] archive) {
        OutputStream stream = new OutputStream(archive.length + 4);

        stream.writeByte(indexId);
        stream.writeShort(archiveId);
        stream.writeByte(0);
        stream.writeInt(archive.length);

        int offset = 8;

        for (int i = 0; i < archive.length; i++) {
            if (offset == 512) {
                stream.writeByte(-1);
                offset = 1;
            }

            stream.writeByte(archive[i]);
            offset++;
        }

        byte[] data = new byte[stream.getOffset()];
        stream.setOffset(0);
        stream.getBytes(data, 0, data.length);
        return data;
    }

    public static int getNameHash(String name) {
        return name.toLowerCase(Locale.getDefault()).hashCode();
    }
}
